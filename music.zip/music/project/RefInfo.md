
# 參考資料

## 偵測視窗的叉叉"X" 並關掉程式(event)參考：
 * https://stackoverflow.com/questions/36342997/allegro5-window-wont-close
 * https://www.aprendendoallegro.tk/eventos.php
 * https://www.allegro.cc/manual/5/al_wait_for_event_timed

## branch test
